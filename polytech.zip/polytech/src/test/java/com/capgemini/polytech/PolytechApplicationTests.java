package com.capgemini.polytech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolytechApplicationTests {

	@Test
	void contextLoads() {
	}

}
